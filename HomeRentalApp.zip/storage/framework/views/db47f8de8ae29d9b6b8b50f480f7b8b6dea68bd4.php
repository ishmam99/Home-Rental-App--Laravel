<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>EstateAgency Bootstrap Template</title>
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <meta content="" name="keywords">
  <meta content="" name="description">

  <!-- Favicons -->
  <link href="<?php echo e(asset('frontend/img/favicon.png')); ?>" rel="icon">
  <link href="<?php echo e(asset('frontend/img/apple-touch-icon.png')); ?>" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.css">
  <!-- Bootstrap CSS File -->
  <link href="<?php echo e(asset('frontend/lib/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">

  <!-- Libraries CSS Files -->
  <link href="<?php echo e(asset('frontend/lib/font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('frontend/lib/animate/animate.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('frontend/lib/ionicons/css/ionicons.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('frontend/lib/owlcarousel/assets/owl.carousel.min.css')); ?>" rel="stylesheet">

  <!-- Main Stylesheet File -->
  <link href="<?php echo e(asset('frontend/css/style.css')); ?>" rel="stylesheet">

  
</head>

<body>

  <div class="click-closed"></div>
  <!--/ Form Search Star /-->
  <div class="box-collapse">
    <div class="title-box-d">
      <h3 class="title-d">Search Property</h3>
    </div>
    <span class="close-box-collapse right-boxed ion-ios-close"></span>
    <div class="box-collapse-wrap form">
      <form class="form-a">
        <div class="row">
          <div class="col-md-12 mb-2">
            <div class="form-group">
              <label for="Type">Keyword</label>
              <input type="text" class="form-control form-control-lg form-control-a" placeholder="Keyword">
            </div>
          </div>
          <div class="col-md-6 mb-2">
            <div class="form-group">
              <label for="Type">Type</label>
              <select class="form-control form-control-lg form-control-a" id="Type">
                <option>All Type</option>
                <option>For Rent</option>
                <option>For Sale</option>
                <option>Open House</option>
              </select>
            </div>
          </div>
          <div class="col-md-6 mb-2">
            <div class="form-group">
              <label for="city">City</label>
              <select class="form-control form-control-lg form-control-a" id="city">
                <option>All City</option>
                <option>Alabama</option>
                <option>Arizona</option>
                <option>California</option>
                <option>Colorado</option>
              </select>
            </div>
          </div>
          <div class="col-md-6 mb-2">
            <div class="form-group">
              <label for="bedrooms">Bedrooms</label>
              <select class="form-control form-control-lg form-control-a" id="bedrooms">
                <option>Any</option>
                <option>01</option>
                <option>02</option>
                <option>03</option>
              </select>
            </div>
          </div>
          <div class="col-md-6 mb-2">
            <div class="form-group">
              <label for="garages">Garages</label>
              <select class="form-control form-control-lg form-control-a" id="garages">
                <option>Any</option>
                <option>01</option>
                <option>02</option>
                <option>03</option>
                <option>04</option>
              </select>
            </div>
          </div>
          <div class="col-md-6 mb-2">
            <div class="form-group">
              <label for="bathrooms">Bathrooms</label>
              <select class="form-control form-control-lg form-control-a" id="bathrooms">
                <option>Any</option>
                <option>01</option>
                <option>02</option>
                <option>03</option>
              </select>
            </div>
          </div>
          <div class="col-md-6 mb-2">
            <div class="form-group">
              <label for="price">Min Price</label>
              <select class="form-control form-control-lg form-control-a" id="price">
                <option>Unlimite</option>
                <option>$50,000</option>
                <option>$100,000</option>
                <option>$150,000</option>
                <option>$200,000</option>
              </select>
            </div>
          </div>
          <div class="col-md-12">
            <button type="submit" class="btn btn-b">Search Property</button>
          </div>
        </div>
      </form>
    </div>
  </div>
  <!--/ Form Search End /-->

  <!--/ Nav Star /-->
  <nav class="navbar navbar-default navbar-trans navbar-expand-lg fixed-top">
    <div class="container">
      <button class="navbar-toggler collapsed" type="button" data-toggle="collapse" data-target="#navbarDefault"
        aria-controls="navbarDefault" aria-expanded="false" aria-label="Toggle navigation">
        <span></span>
        <span></span>
        <span></span>
      </button>
      <a class="navbar-brand text-brand" href="<?php echo e(URL::to('/')); ?>">Estate<span class="color-b">Agency</span></a>
      <button type="button" class="btn btn-link nav-search navbar-toggle-box-collapse d-md-none" data-toggle="collapse"
        data-target="#navbarTogglerDemo01" aria-expanded="false">
        <span class="fa fa-search" aria-hidden="true"></span>
      </button>
      <div class="navbar-collapse collapse justify-content-center" id="navbarDefault">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link " href="<?php echo e(url('/')); ?>">Home</a>
          </li>
          <li class="nav-item">
            <?php if(Auth::check()&& Auth::user()->role_id==1): ?>
                <a class="nav-link" href="<?php echo e(route('admin')); ?>">Profile</a>
            <?php else: ?>
                 <a class="nav-link" href="<?php echo e(route('home')); ?>">Profile</a>
            <?php endif; ?>
           
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('rents')); ?>">Rents</a>
          </li>
          <?php if(Auth::check()&& Auth::user()->role_id==2): ?>
               <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('create.rent')); ?>">Create Rent</a>
          </li>
          <?php endif; ?>
         
         
          <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('about')); ?>">About</a>
          </li>
         
              <?php if(auth()->guard()->guest()): ?>
                  
              
                  <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Sign in')); ?></a>
                                </li>
              <?php else: ?>
                   <li class="nav-item"> <a class="nav-link" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?>

                                    </a>
             <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                        <?php echo csrf_field(); ?>
                                    </form> </li>
             <?php endif; ?>
               
         
        </ul>
      </div>
      <button type="button" class="btn btn-b-n navbar-toggle-box-collapse d-none d-md-block" data-toggle="collapse"
        data-target="#navbarTogglerDemo01" aria-expanded="false">
        <span class="fa fa-search" aria-hidden="true"></span>
      </button>
    </div>
  </nav>
  <!--/ Nav End /-->

  <!--/ Carousel Star /-->

  
  <!--/ Carousel end /-->

  <!--/ Services Star /-->
  <div class="content">

<?php echo $__env->yieldContent('content'); ?>
  </div>
  <!--/ Services End /-->

  <!--/ Property Star /-->
 
  <!--/ Property End /-->

  <!--/ Agents Star /-->
  
  <!--/ Agents End /-->

  <!--/ News Star /-->
 
  <!--/ News End /-->



<footer>
   <div class="copyright-footer">
            <p class="copyright color-text-a">
              &copy; Copyright
              <span class="color-a">EstateAgency</span> All Rights Reserved.
            </p>
          </div>
</footer>


  <!-- JavaScript Libraries -->
  <script src="<?php echo e(asset('frontend/lib/jquery/jquery.min.js')); ?>"></script>
  <script src="<?php echo e(asset('frontend/lib/jquery/jquery-migrate.min.js')); ?>"></script>
  <script src="<?php echo e(asset('frontend/lib/popper/popper.min.js')); ?>"></script>
  <script src="<?php echo e(asset('frontend/lib/bootstrap/js/bootstrap.min.js')); ?>"></script>
  <script src="<?php echo e(asset('frontend/lib/easing/easing.min.js')); ?>"></script>
  <script src="<?php echo e(asset('frontend/lib/owlcarousel/owl.carousel.min.js')); ?>"></script>
  <script src="<?php echo e(asset('frontend/lib/scrollreveal/scrollreveal.min.js')); ?>"></script>
  <!-- Contact Form JavaScript File -->
  <script src="<?php echo e(asset('frontend/contactform/contactform.js')); ?>"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
  <!-- Template Main Javascript File -->
  <script src="<?php echo e(asset('frontend/js/main.js')); ?>"></script>
  <script>
        <?php if(Session::has('messege')): ?>
          var type="<?php echo e(Session::get('alert-type','info')); ?>"
          switch(type){
              case 'info':
                   toastr.info("<?php echo e(Session::get('messege')); ?>");
                   break;
              case 'success':
                  toastr.success("<?php echo e(Session::get('messege')); ?>");
                  break;
              case 'warning':
                 toastr.warning("<?php echo e(Session::get('messege')); ?>");
                  break;
              case 'error':
                  toastr.error("<?php echo e(Session::get('messege')); ?>");
                  break;
          }
        <?php endif; ?>
     </script>  
    <script>
      
       $(document).ready(function(){
         var links =$('li').children();
         $.each(links, function(key, value){
           if(value.href ==document.URL)
           {
             $(this).addClass('active');
           }
         });
       })
    </script>

</body>
</html>

<?php /**PATH D:\Laravel\HomeRentalApp\resources\views/layouts/app.blade.php ENDPATH**/ ?>