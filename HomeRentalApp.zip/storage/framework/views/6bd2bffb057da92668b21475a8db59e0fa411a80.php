
  
     <?php $__env->startSection('content'); ?>
      <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                     <h2>Rents</h2>   
                        <h5>Welcome Admin, Love to see you back. </h5>
                       
                    </div>
                </div>
                 <!-- /. ROW  -->
                 <hr />
               
            <div class="row">
                <div class="col-md-12">
                    <!-- Advanced Tables -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                             Rents Table
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>  
                                            <th>Renter Name</th>
                                            <th>Location</th>
                                            <th>Rent Fee</th>
                                            <th>Renter Phone</th>
                                            <th>Bedrooms</th>
                                             <th>Baths</th>
                                             <th>Balcony</th>
                                             <th>Status</th>
                                           
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $rents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            
                                        
                                        <tr class="odd gradeX">
                                            <td><?php echo e($item->name); ?></td>
                                            <td><?php echo e($item->location); ?></td>
                                         
                                            <td ><?php echo e($item->rent_fee); ?></td>
                                             <td><?php echo e($item->phone); ?></td>
                                             <td><?php echo e($item->bedroom); ?></td>
                                             <td><?php echo e($item->toilet); ?></td>
                                             <td><?php echo e($item->balcony); ?></td>
                                             <td ><?php if($item->status==TRUE): ?>
                                                <button class="btn btn-primary">Active </button> 
                                             <?php else: ?>
                                                 <button class="btn btn-warning">Booked </button> 
                                             <?php endif; ?></td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                            
                        </div>
                    </div>
                    <!--End Advanced Tables -->
                </div>
            </div>
 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\HomeRentalApp\resources\views/backend/rents.blade.php ENDPATH**/ ?>